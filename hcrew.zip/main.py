from dotenv import load_dotenv
from crew.crew import crew
from tools.tools import load_sop_data  

load_dotenv()


def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text


email_pdf_path = "path_to_your_email_thread.pdf"
sop_pdf_path = "path_to_your_sop_data.pdf"


email_thread = extract_text_from_pdf(email_pdf_path)


sop_data = load_sop_data(sop_pdf_path)


result = crew.kickoff(inputs={"input": email_thread, "sop_data": sop_data})


print("\n\nFINAL OUTPUT:\n", result)
