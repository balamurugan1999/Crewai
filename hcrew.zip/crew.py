from typing import Optional, List, Literal
from pydantic import BaseModel, Field

#from crewai.knowledge.source.pdf_knowledge_source import PDFKnowledgeSource
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai.llm import LLM




#pdf_source = PDFKnowledgeSource(file_paths=["data.pdf"])



llm = LLM(model="gpt-4o")


class SummarizerTask(BaseModel):
    email_thread: str = Field(..., description="The entire email conversation to be summarized.")


class SentimentTask(BaseModel):
    email_thread: str = Field(..., description="The same email thread used to analyze sentiment.")


class SOPTask(BaseModel):
    summarized_email: str = Field(..., description="The summarized version of the email.")
    sentiment: Literal["Positive", "Neutral", "Negative"] = Field(..., description="Sentiment label.")




"""def load_yaml_config(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)"""




@CrewBase
class TripadvisorCrew:
    """Tripadvisorcrew crew"""

    agents_config_path = "config/agents.yaml"
    tasks_config_path = "config/tasks.yaml"

    """def __init__(self):
        self.agents_config = load_yaml_config(self.agents_config_path)
        self.tasks_config = load_yaml_config(self.tasks_config_path)"""

    @agent
    def summarizer_agent(self) -> Agent:
        
        return Agent(
            verbose=True,
            allow_delegation=False,
            llm=llm,
            config = self.agents_config["summarizer_agent"]
        )

    @agent
    def sentiment_agent(self) -> Agent:
       
        return Agent(
            
            config = self.agents_config["sentiment_agent"],
            verbose=True,
            allow_delegation=False,
            llm=llm,
            
        )

    @agent
    def sop_resolver_agent(self) -> Agent:
       
        return Agent(
            
            config = self.agents_config["sop_resolver_agent"],
            verbose=True,
            allow_delegation=False,
            llm=llm,
           
        )

    @task
    def summarizer_task(self) -> Task:
       
        return Task(
           
            config = self.tasks_config["summarizer_task"],
            output_pydantic=SummarizerTask
        )

    @task
    def sentiment_task(self) -> Task:
        
        return Task(
            config = self.tasks_config["sentiment_task"],
            output_pydantic=SentimentTask
           
        )

    @task
    def sop_task(self) -> Task:
        
        return Task(
            config = self.tasks_config["sop_task"],
            output_pydantic=SOPTask
           
        )
    
    @crew
    def crew(self) -> Crew:
        """Creates the Tripadvisorcrew crew"""

        return Crew(
            agents=self.agents,
            tasks=self.tasks,
            process=Process.sequential,
            verbose=True,
        )
    

crew_runner=Tripadvisorcrew().crew()
result = crew_runner.kickoff(inputs={
        "email_thread": """From: Sarah Lee (Client)
To: Jordan Miles (Freelancer)
Date: April 15, 2025
Time: 9:02 AM

Hi Jordan,

Hope you're doing well! We're looking to do a light refresh of our website's homepage and wanted to see if you'd be available to help out. Mostly some layout tweaks and updated visuals.

Let me know if you have time in the next week or two. I can send over more details.

Best,
Sarah

From: Jordan Miles (Freelancer)
To: Sarah Lee (Client)
Date: April 15, 2025
Time: 10:27 AM

Hi Sarah,

Great to hear from you! I’d love to help with the homepage refresh. I have some availability starting Thursday this week, so feel free to send over the details and any assets you already have in mind.

Looking forward to it.

Best,
Jordan

From: Sarah Lee
To: Jordan Miles
Date: April 15, 2025
Time: 1:15 PM

Thanks, Jordan! I’ve attached a PDF with the current homepage layout, plus some notes on what we’re thinking (section spacing, updated hero image, call-to-action button colors, etc.).

Let me know if you have any questions. No rush on timeline—next week would be perfect.

Best,
Sarah

From: Jordan Miles
To: Sarah Lee
Date: April 16, 2025
Time: 8:41 AM

Hey Sarah,

Got the PDF—thanks! Everything looks clear. I’ll put together a quick mockup by Monday and send it your way for feedback.

Talk soon,
Jordan"""
        
    })

print(result)